"""Detect microsaccades"""

__version__ = '0.2.4'

from pycrosaccade._pycrosaccade import find_microsaccades, microsaccades